import { Employee, Role, MasteryLevel, SkillStatus } from "./types";

export const MOCK_EMPLOYEES: Employee[] = [
  {
    id: "1",
    name: "Selin Yılmaz",
    role: Role.SalesAssistant,
    level: MasteryLevel.Competent,
    tenure: "5 Ay",
    strongPoint: "Satış & Servis (Conversion Lift)",
    growthEdge: "One Store Derinliği",
    tendency: [3.2, 3.5, 4.1, 4.2],
    asaMap: [
      { label: "Mağaza Operasyonu", weight: 25, status: "neutral" },
      { label: "Müşteri Servisi", weight: 25, status: "strong" },
      { label: "Satış", weight: 40, status: "strong" },
      { label: "Kendini Geliştirme", weight: 10, status: "developing" },
    ],
    skills: [
      { topic: "Conversion Lifts", status: SkillStatus.CanTeach, date: "2024-05-10" },
      { topic: "One Store Uçtan Uca", status: SkillStatus.NeedImprovement, date: "2024-06-01" },
      { topic: "Koleksiyon Hakimiyeti", status: SkillStatus.CanDo, date: "2024-04-15" },
    ],
    journalEntries: [
      { id: "j1", date: "8 Haziran 2024", note: "Bugün tepe saatte kabin operasyonunu çok sakin ve hatasız yönetti.", author: "Baran B." },
      { id: "j2", date: "1 Haziran 2024", note: "Müşteri ile iletişim kurarken hala biraz çekingen. Satış kapanışta desteğe ihtiyacı var.", author: "Ayşe A." }
    ]
  },
  {
    id: "2",
    name: "Mert Demir",
    role: Role.SalesAssistant,
    level: MasteryLevel.New,
    tenure: "3 Hafta",
    strongPoint: "Operasyonel Hız",
    growthEdge: "Satış Kapanış",
    tendency: [1.5, 2.1, 2.4, 2.6],
    asaMap: [
      { label: "Mağaza Operasyonu", weight: 30, status: "strong" },
      { label: "Müşteri Servisi", weight: 20, status: "developing" },
      { label: "Satış", weight: 20, status: "developing" },
      { label: "Kendini Geliştirme", weight: 30, status: "strong" },
    ],
    skills: [
      { topic: "Mağaza Düzeni", status: SkillStatus.CanDo, date: "2024-06-05" },
      { topic: "Müşteri Yaklaşımı", status: SkillStatus.Theory, date: "2024-06-02" },
    ],
    journalEntries: [
      { id: "j3", date: "5 Haziran 2024", note: "İlk haftasını tamamladı, tempo ve mağaza düzenine çok hızlı adapte oldu. Müşteri yaklaşımı pratikleriyle desteklenmeli.", author: "Baran B." }
    ]
  },
  {
    id: "3",
    name: "Baran B.",
    role: Role.SalesAssistant,
    level: MasteryLevel.Coach,
    tenure: "2 Yıl",
    strongPoint: "Ekip Yönetimi & KPI Köprüsü",
    growthEdge: "Geri Bildirim Döngüsü",
    tendency: [4.8, 4.9, 4.9, 5.0],
    asaMap: [
      { label: "Mağaza Operasyonu", weight: 25, status: "strong" },
      { label: "Müşteri Servisi", weight: 25, status: "strong" },
      { label: "Satış", weight: 25, status: "strong" },
      { label: "Kendini Geliştirme", weight: 25, status: "strong" },
    ],
    skills: [
      { topic: "Koçluk Becerileri", status: SkillStatus.CanTeach, date: "2023-12-01" },
      { topic: "KPI Analizi", status: SkillStatus.CanTeach, date: "2024-01-10" },
    ]
  }
];

export const MOCK_NOTIFICATIONS: any[] = [
  {
    id: "n1",
    type: "urgent",
    message: "Acil: Z2 Alanında operasyonel yoğunluk tespit edildi. Mert D. desteğe yönlendirildi.",
    time: "2 dk önce"
  },
  {
    id: "n2",
    type: "info",
    message: "Eğitim Hatırlatıcı: Yarın 09:00'da Koleksiyon Hakimiyeti eğitimi başlayacak.",
    time: "1 saat önce"
  },
  {
    id: "n3",
    type: "success",
    message: "Selin Y. 'One Store' yetkinliğini 'Öğretebilir' seviyesine yükseltti.",
    time: "3 saat önce"
  }
];

export const MOCK_AGENDA: any[] = [
  {
    id: "a1",
    type: "Mentorluk",
    title: "Usta Aktarımı: One Store Derinliği",
    date: "11 Haziran",
    time: "10:30",
    participants: ["Selin Y.", "Mert D."],
    location: "Eğitim Odası"
  },
  {
    id: "a2",
    type: "Eğitim",
    title: "Koleksiyon Hakimiyeti & Trendler",
    date: "12 Haziran",
    time: "09:00",
    participants: ["Tüm Ekip"],
    location: "Mağaza Alanı"
  },
  {
    id: "a3",
    type: "Toplantı",
    title: "Haftalık KPI Değerlendirmesi",
    date: "13 Haziran",
    time: "14:00",
    participants: ["Mağaza Müdürü", "Baran B."],
    location: "Ofis"
  }
];
