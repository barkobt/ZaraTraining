import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Calendar as CalendarIcon, FileText, ChevronLeft, ChevronRight, Activity } from "lucide-react";
import { LineChart, Line, XAxis, Tooltip, ResponsiveContainer } from "recharts";
import { Employee } from "../types";

interface ArchiveNote {
  id: string;
  date: string;
  type: "Gözlem" | "Koçluk" | "Değerlendirme";
  topic: string;
  notes: string;
  author: string;
  signature: boolean;
  sentiment: number;
}

const MOCK_ARCHIVE_NOTES: ArchiveNote[] = [
  {
    id: "a4",
    date: "2026-05-28",
    type: "Gözlem",
    topic: "Mağaza Kapanış Prosedürleri",
    notes: "Kapanış checklist'i üzerinden birebir geçildi. Eksiksiz ve zamanında tamamladı.",
    author: "Ayşe A.",
    signature: true,
    sentiment: 75
  },
  {
    id: "a3",
    date: "2026-06-01",
    type: "Değerlendirme",
    topic: "Aylık Gelişim Özeti",
    notes: "Genel mağaza düzenine uyum yüksek. Depo-reyon trafiğini hızlı yönetiyor. İleri seviye beklentilere geçiş için kasa eğitimlerinin %80'i tamamlandı.",
    author: "Baran B.",
    signature: true,
    sentiment: 85
  },
  {
    id: "a2",
    date: "2026-06-05",
    type: "Koçluk",
    topic: "Ürün Bilgisi ve Çapraz Satış",
    notes: "Reyonda shadowing yapıldı. Yeni sezon denim ürünlerinin kalıp özellikleri (fit guide) üzerinden geçildi. Müşteriye doğru bedeni önerme konusunda teorik bilgisi tam, ancak bunu satışa çevirmede çekimser kalıyor.",
    author: "Ayşe A.",
    signature: true,
    sentiment: 60
  },
  {
    id: "a1",
    date: "2026-06-08",
    type: "Gözlem",
    topic: "Müşteri Karşılama Dinamikleri",
    notes: "Yoğun saatlerde kasada bekleyen müşterilerle göz teması kurarak bekleme stresini azaltmada oldukça başarılı. Ancak iptal/iade süreçlerinde prosedürü hatırlamakta kısa süreli duraksamalar yaşadı. ASA rehberinden 'Drop-off' maddesi tekrar edilmeli.",
    author: "Baran B.",
    signature: true,
    sentiment: 70
  }
];

export default function DigitalArchive({ employee }: { employee: Employee }) {
  const [selectedNote, setSelectedNote] = useState<ArchiveNote | null>(null);

  // Parse notes data for the chart
  const sentimentData = [...MOCK_ARCHIVE_NOTES].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()).map(n => ({
    date: n.date.split("-").slice(1).join("/"), 
    Motivasyon: n.sentiment,
    topic: n.topic
  }));

  return (
    <div className="flex flex-col lg:flex-row gap-8">
      {/* Calendar Layout */}
      <div className="lg:w-1/2 space-y-6">
        <div className="flex items-center justify-between border-b border-ink/20 pb-4">
          <div className="flex items-center gap-2">
            <CalendarIcon size={18} className="opacity-40" />
            <h3 className="font-serif text-2xl font-bold">Haziran 2026</h3>
          </div>
          <div className="flex gap-2">
            <button className="p-2 border border-ink/20 hover:bg-ink/5 transition-all"><ChevronLeft size={16} /></button>
            <button className="p-2 border border-ink/20 hover:bg-ink/5 transition-all"><ChevronRight size={16} /></button>
          </div>
        </div>

        {/* Sentiment Trend Chart */}
        <div className="art-card p-4">
          <div className="flex items-center justify-between mb-4">
            <div className="label-caps opacity-40">Duygu Durum & Motivasyon Eğilimi</div>
            <Activity size={14} className="opacity-40" />
          </div>
          <div className="h-32 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={sentimentData} margin={{ top: 5, right: 10, left: 10, bottom: 5 }}>
                <XAxis 
                  dataKey="date" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fontFamily: 'Inter', opacity: 0.5 }} 
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#F5F2ED', border: '1px solid #1A1A1A', fontSize: '10px', borderRadius: '0' }}
                  labelStyle={{ fontFamily: 'Inter', fontWeight: 'bold' }}
                />
                <Line 
                  type="monotone" 
                  dataKey="Motivasyon" 
                  stroke="#1A1A1A" 
                  strokeWidth={2} 
                  dot={{ r: 3, strokeWidth: 2, fill: '#F5F2ED' }} 
                  activeDot={{ r: 5 }} 
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4">
          {/* MOCK_ARCHIVE_NOTES is reversed so newest is on top */}
          {[...MOCK_ARCHIVE_NOTES].reverse().map((note, i) => (
            <motion.div
              key={note.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              onClick={() => setSelectedNote(note)}
              className={`p-4 border cursor-pointer transition-all ${selectedNote?.id === note.id ? 'border-ink bg-ink/5' : 'border-ink/20 hover:border-ink/50'}`}
            >
              <div className="flex justify-between items-start mb-2">
                <div className="label-caps !text-[10px] opacity-60 bg-ink/5 px-2 py-1">{note.date}</div>
                <div className="label-caps !text-[9px] opacity-40">{note.type}</div>
              </div>
              <h4 className="font-serif font-bold text-lg mb-1">{note.topic}</h4>
              <p className="font-serif text-sm opacity-60 italic line-clamp-1">{note.notes}</p>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Paper Form Preview */}
      <div className="lg:w-1/2">
        <AnimatePresence mode="popLayout">
          {selectedNote ? (
            <motion.div
              key={selectedNote.id}
              initial={{ opacity: 0, scale: 0.98, rotate: -1 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              exit={{ opacity: 0, scale: 0.98, rotate: 1 }}
              className="bg-[#Fdfbf7] border border-ink/30 p-8 md:p-12 shadow-sm relative overflow-hidden"
              style={{
                backgroundImage: 'repeating-linear-gradient(transparent, transparent 31px, rgba(0,0,0,0.05) 31px, rgba(0,0,0,0.05) 32px)',
                backgroundAttachment: 'local',
                backgroundPosition: '0 0'
              }}
            >
              {/* Form Header */}
              <div className="border-b-2 border-ink pb-6 mb-8 flex justify-between items-end bg-[#Fdfbf7]">
                <div>
                  <div className="label-caps opacity-40 mb-1">Gözlem Formu / No: {selectedNote.id.padStart(4, '0')}</div>
                  <h3 className="font-serif text-3xl font-bold uppercase">{selectedNote.topic}</h3>
                </div>
                <div className="text-right">
                  <div className="label-caps !text-[9px] opacity-40 mb-1">Tarih</div>
                  <div className="font-serif font-bold">{selectedNote.date.split('-').reverse().join('.')}</div>
                </div>
              </div>

              {/* Form Body */}
              <div className="space-y-8 bg-[#Fdfbf7] bg-opacity-80">
                <div>
                  <div className="label-caps !text-[9px] opacity-40 mb-2">Değerlendirilen Çalışan</div>
                  <div className="font-serif text-xl border-b border-ink/20 pb-1">{employee.name}</div>
                </div>

                <div>
                  <div className="label-caps !text-[9px] opacity-40 mb-2">Gözlem & Notlar</div>
                  <p className="font-serif text-lg leading-loose italic">
                    {selectedNote.notes}
                  </p>
                </div>
              </div>

              {/* Form Footer */}
              <div className="mt-16 pt-8 border-t border-ink/20 flex justify-between items-end bg-[#Fdfbf7]">
                <div>
                  <div className="label-caps !text-[9px] opacity-40 mb-1">Koç / Gözlemci</div>
                  <div className="font-serif text-lg">{selectedNote.author}</div>
                </div>
                {selectedNote.signature && (
                  <div className="text-right">
                    <div className="label-caps !text-[9px] opacity-40 mb-2">İmza / Onay</div>
                    <div className="font-serif italic text-2xl opacity-60" style={{ fontFamily: '"Playfair Display", serif' }}>
                      {selectedNote.author.replace('.', '')}
                    </div>
                  </div>
                )}
              </div>
              
              {/* Paper Watermark */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 border-4 border-ink/5 rounded-full w-64 h-64 flex items-center justify-center -z-10 transform -rotate-12 pointer-events-none">
                <span className="font-serif text-4xl uppercase tracking-widest opacity-5">Arşiv</span>
              </div>
            </motion.div>
          ) : (
            <div className="h-full min-h-[400px] border border-ink/10 flex flex-col items-center justify-center text-center p-8 bg-ink/5">
              <FileText size={48} className="opacity-20 mb-4" />
              <p className="font-serif italic opacity-40 max-w-sm">
                Takvimden bir gözlem formu seçerek dijital arşiv dökümünü inceleyebilirsiniz.
              </p>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
