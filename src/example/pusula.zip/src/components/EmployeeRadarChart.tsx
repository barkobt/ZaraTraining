import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { Employee } from '../types';

interface EmployeeRadarChartProps {
  employees: Employee[];
}

export default function EmployeeRadarChart({ employees }: EmployeeRadarChartProps) {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current || employees.length === 0) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const width = 400;
    const height = 400;
    const margin = 60;
    const radius = Math.min(width, height) / 2 - margin;

    // Feature scaling: 'strong' = 5, 'neutral' = 3, 'developing' = 2
    const data = employees.map(emp => ({
      name: emp.name,
      axes: emp.asaMap.map(asa => {
        let val = 1;
        if (asa.status === 'strong') val = 5;
        else if (asa.status === 'neutral') val = 3;
        else if (asa.status === 'developing') val = 2;
        return { axis: asa.label, value: val };
      })
    }));

    const features = data[0].axes.map(a => a.axis);
    const angleSlice = (Math.PI * 2) / features.length;

    const rScale = d3.scaleLinear().range([0, radius]).domain([0, 5]);

    const colors = ['#1A1A1A', '#A39D8D', '#6B6B6B'];

    const g = svg.append("g")
      .attr("transform", `translate(${width / 2},${height / 2})`);

    // Draw circular grid lines
    const ticks = [1, 2, 3, 4, 5];
    ticks.forEach(tick => {
      g.append("circle")
        .attr("r", rScale(tick))
        .style("fill", "none")
        .style("stroke", "rgba(26, 26, 26, 0.1)")
        .style("stroke-dasharray", "2 2");
    });

    // Draw axes
    const axis = g.selectAll(".axis")
      .data(features)
      .enter()
      .append("g")
      .attr("class", "axis");

    axis.append("line")
      .attr("x1", 0)
      .attr("y1", 0)
      .attr("x2", (d, i) => rScale(5) * Math.cos(angleSlice * i - Math.PI / 2))
      .attr("y2", (d, i) => rScale(5) * Math.sin(angleSlice * i - Math.PI / 2))
      .style("stroke", "rgba(26, 26, 26, 0.2)")
      .style("stroke-width", "1px");

    axis.append("text")
      .attr("class", "legend")
      .style("font-size", "10px")
      .style("font-family", "Inter")
      .style("font-weight", "600")
      .style("text-transform", "uppercase")
      .style("letter-spacing", "0.1em")
      .attr("text-anchor", "middle")
      .attr("dy", "0.35em")
      .attr("x", (d, i) => rScale(5) * 1.2 * Math.cos(angleSlice * i - Math.PI / 2))
      .attr("y", (d, i) => rScale(5) * 1.2 * Math.sin(angleSlice * i - Math.PI / 2))
      .text(d => d)
      .style("fill", "rgba(26, 26, 26, 0.6)");

    // Draw radar blobs
    const radarLine = d3.lineRadial<{ axis: string; value: number }>()
      .angle((d, i) => i * angleSlice)
      .radius(d => rScale(d.value))
      .curve(d3.curveLinearClosed);

    data.forEach((d, i) => {
      const gBlob = g.append("g").attr("class", "radarWrapper");

      gBlob.append("path")
        .attr("class", "radarArea")
        .attr("d", radarLine(d.axes))
        .style("fill", colors[i % colors.length])
        .style("fill-opacity", 0.1)
        .style("stroke", colors[i % colors.length])
        .style("stroke-width", 2)
        .on("mouseover", function() {
          d3.select(this).style("fill-opacity", 0.4);
        })
        .on("mouseout", function() {
          d3.select(this).style("fill-opacity", 0.1);
        });

      gBlob.selectAll(".radarCircle")
        .data(d.axes)
        .enter().append("circle")
        .attr("class", "radarCircle")
        .attr("r", 4)
        .attr("cx", (dData, j) => rScale(dData.value) * Math.cos(angleSlice * j - Math.PI / 2))
        .attr("cy", (dData, j) => rScale(dData.value) * Math.sin(angleSlice * j - Math.PI / 2))
        .style("fill", colors[i % colors.length])
        .style("fill-opacity", 0.8);
    });

  }, [employees]);

  return (
    <div className="flex flex-col items-center">
      <svg ref={svgRef} width="400" height="400" className="max-w-full h-auto"></svg>
      <div className="flex gap-6 mt-4">
        {employees.map((emp, i) => {
          const colors = ['#1A1A1A', '#A39D8D', '#6B6B6B'];
          return (
            <div key={emp.id} className="flex items-center gap-2 label-caps">
              <div 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: colors[i % colors.length] }}
              ></div>
              <span className="opacity-60">{emp.name}</span>
            </div>
          )
        })}
      </div>
    </div>
  );
}
