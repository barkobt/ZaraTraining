import { motion } from "motion/react";
import { X, AlertCircle, Info, CheckCircle2 } from "lucide-react";
import { MOCK_NOTIFICATIONS } from "../mockData";

interface NotificationPanelProps {
  onClose: () => void;
}

export default function NotificationPanel({ onClose }: NotificationPanelProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="absolute right-0 top-16 w-96 bg-canvas border border-ink z-[100] shadow-2xl p-6"
    >
      <div className="flex items-center justify-between border-b border-border pb-4 mb-4">
        <h4 className="label-caps !tracking-[0.1em]">UYARI PANELİ</h4>
        <button onClick={onClose} className="opacity-40 hover:opacity-100 transition-opacity">
          <X size={16} />
        </button>
      </div>

      <div className="space-y-6">
        {MOCK_NOTIFICATIONS.map((notif) => (
          <div key={notif.id} className="flex gap-4 group">
            <div className={`shrink-0 mt-1 ${
              notif.type === 'urgent' ? 'text-red-500' :
              notif.type === 'info' ? 'text-ink/60' :
              'text-green-600'
            }`}>
              {notif.type === 'urgent' && <AlertCircle size={18} />}
              {notif.type === 'info' && <Info size={18} />}
              {notif.type === 'success' && <CheckCircle2 size={18} />}
            </div>
            <div className="flex-1">
              <p className="font-serif text-[13px] leading-relaxed italic opacity-80 mb-1">
                "{notif.message}"
              </p>
              <span className="label-caps !text-[8px] opacity-40 italic">{notif.time}</span>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 pt-4 border-t border-border">
        <button className="w-full label-caps text-[9px] py-3 border border-ink/10 hover:border-ink transition-all">
          Tümünü Arşivle
        </button>
      </div>
    </motion.div>
  );
}
