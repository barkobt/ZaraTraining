import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Users, Calendar, ArrowRight, BrainCircuit, RefreshCw, Zap } from "lucide-react";
import { Employee } from "../types";
import { MOCK_EMPLOYEES } from "../mockData";

type ShiftType = "Sabah (09:00 - 18:00)" | "Öğle (12:00 - 21:00)" | "Akşam (15:00 - 22:00)";

interface Match {
  id: string;
  mentor: Employee;
  mentee: Employee;
  focusArea: string;
  reason: string;
  shift: ShiftType;
  matchScore: number;
  aiSuggested: boolean;
}

const SHIFT_SCHEDULE: Record<string, ShiftType> = {
  "Ayşe A.": "Sabah (09:00 - 18:00)",
  "Baran B.": "Sabah (09:00 - 18:00)",
  "Selin Y.": "Öğle (12:00 - 21:00)",
  "Deniz Y.": "Sabah (09:00 - 18:00)",
  "Kerem T.": "Akşam (15:00 - 22:00)",
  "Elif N.": "Öğle (12:00 - 21:00)",
};

const INITIAL_MATCHES: Match[] = [
  {
    id: "m1",
    mentor: MOCK_EMPLOYEES[0], // Ayşe A. (Expert)
    mentee: MOCK_EMPLOYEES[1], // Baran B. (New)
    focusArea: "Kasa İadeleri ve İletişim",
    reason: "Ayşe'nin Kasa Operasyonlarındaki yüksek yetkinliği (Öğretebilir seviye), Baran'ın bu alandaki ilk günleri ile örtüşüyor.",
    shift: "Sabah (09:00 - 18:00)",
    matchScore: 92,
    aiSuggested: true,
  },
  {
    id: "m2",
    mentor: MOCK_EMPLOYEES[2], // Selin
    mentee: MOCK_EMPLOYEES[3] || MOCK_EMPLOYEES[1], // Deniz or someone else
    focusArea: "Reyon Yönetimi ve Ürün Bilgisi",
    reason: "Selin dün reyonda çok iyi bir müşteri geri bildirimi aldı, Deniz'in ise departmanlar konusundaki teorik bilgisini pratiğe dökmesi gerekiyor.",
    shift: "Öğle (12:00 - 21:00)",
    matchScore: 85,
    aiSuggested: true,
  }
];

export default function MentorMatrix() {
  const [day, setDay] = useState("Bugün");
  const [matches, setMatches] = useState<Match[]>(INITIAL_MATCHES);
  const [isOptimizing, setIsOptimizing] = useState(false);

  const handleOptimize = () => {
    setIsOptimizing(true);
    setTimeout(() => {
      // Simulate learning & re-shuffling based on shifts and recent performance
      setMatches([
        {
          id: "m3",
          mentor: MOCK_EMPLOYEES[0], // Ayşe
          mentee: MOCK_EMPLOYEES[3] || MOCK_EMPLOYEES[1], // Deniz
          focusArea: "Drop-off Çıkış ve Hızlı Aksiyon",
          reason: "Model dünkü yoğun vardiyada Deniz'in drop-off bekleme sürelerini uzun buldu. Ayşe bu konuda mağazanın en iyilerinden (Vardiya eşleşmesi onaylandı).",
          shift: "Sabah (09:00 - 18:00)",
          matchScore: 96,
          aiSuggested: true,
        },
        ...matches.filter(m => m.id === "m2")
      ]);
      setIsOptimizing(false);
    }, 1500);
  };

  return (
    <div className="space-y-8 pb-12">
      <div className="flex flex-col md:flex-row justify-between gap-6 border-b border-border pb-6">
        <div>
          <h3 className="font-serif text-2xl font-bold tracking-tight mb-2">Mentorluk Eşleşme Matrisi</h3>
          <p className="font-serif italic opacity-60 text-sm max-w-xl">
            Sistem yetkinlik boşluklarını ve o günkü vardiya (shift) çakışmalarını analiz ederek en yüksek verimi alabileceğiniz eşleşmeleri önerir. Model zamanla öğrenir.
          </p>
        </div>
        
        <div className="flex items-center gap-4 self-start">
          <div className="bg-canvas border border-ink/20 p-1 flex">
            {["Dün", "Bugün", "Yarın"].map((d) => (
              <button
                key={d}
                onClick={() => setDay(d)}
                className={`px-4 py-2 label-caps text-[10px] transition-all ${
                  day === d ? "bg-ink text-canvas" : "text-ink hover:bg-ink/5"
                }`}
              >
                {d}
              </button>
            ))}
          </div>
          <button 
            onClick={handleOptimize}
            disabled={isOptimizing}
            className="bg-ink text-canvas px-4 py-2 label-caps flex items-center gap-2 hover:bg-ink/90 transition-all disabled:opacity-50"
          >
            <RefreshCw size={14} className={isOptimizing ? "animate-spin" : ""} />
            {isOptimizing ? "Hesaplanıyor..." : "Yeniden Optimize Et"}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <AnimatePresence mode="popLayout">
          {matches.map((match, idx) => (
            <motion.div
              key={match.id}
              layout
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ delay: idx * 0.1 }}
              className="art-card p-6 flex flex-col group relative overflow-hidden"
            >
              {match.aiSuggested && (
                <div className="absolute top-0 left-0 w-full h-1 bg-ink opacity-20" />
              )}
              
              <div className="flex justify-between items-start mb-6">
                <div>
                  <div className="label-caps opacity-40 mb-1 flex items-center gap-1.5">
                    <Calendar size={12} /> {match.shift}
                  </div>
                  <div className="font-serif font-bold text-lg">{match.focusArea}</div>
                </div>
                {match.aiSuggested && (
                  <div className="label-caps !text-[9px] bg-ink/5 text-ink px-2 py-1 rounded-sm flex items-center gap-1">
                    <BrainCircuit size={12} /> Model Önerisi ({match.matchScore}%)
                  </div>
                )}
              </div>

              <div className="flex items-center gap-4 mb-6 bg-canvas border border-ink/10 p-4 relative">
                <div className="w-8 h-8 rounded-full border border-ink flex items-center justify-center font-serif italic shrink-0">
                  {match.mentor.name.charAt(0)}
                </div>
                <div className="flex-1">
                  <div className="label-caps !text-[9px] opacity-40">Mentor</div>
                  <div className="font-bold leading-none mt-1">{match.mentor.name}</div>
                </div>
                <ArrowRight size={16} className="opacity-30" />
                <div className="flex-1 text-right">
                  <div className="label-caps !text-[9px] opacity-40">Mentee</div>
                  <div className="font-bold leading-none mt-1">{match.mentee?.name || "Öğrenci"}</div>
                </div>
                <div className="w-8 h-8 rounded-full border border-ink border-dashed flex items-center justify-center font-serif italic shrink-0 bg-ink/5">
                  {match.mentee?.name?.charAt(0) || "?"}
                </div>
              </div>

              <div className="bg-ink/5 p-4 flex gap-3 text-sm flex-1">
                <Zap size={14} className="opacity-40 shrink-0 mt-0.5" />
                <p className="font-serif italic opacity-80 leading-relaxed">
                  {match.reason}
                </p>
              </div>
              
              <div className="mt-4 flex gap-2">
                <button className="flex-1 border border-ink/20 py-2 label-caps !text-[10px] hover:border-ink hover:bg-ink hover:text-canvas transition-all">
                  Eşleşmeyi Onayla
                </button>
                <button className="flex-1 border border-ink/20 py-2 label-caps !text-[10px] hover:border-ink hover:bg-ink hover:text-canvas transition-all">
                  Düzenle / Değiştir
                </button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <div className="border border-ink/10 p-6 flex items-start gap-4 mt-8 bg-canvas/50">
        <BrainCircuit size={20} className="shrink-0 opacity-40" />
        <div>
          <h4 className="font-bold font-serif mb-1">Model Nasıl Öğreniyor?</h4>
          <p className="font-serif italic text-sm opacity-70 leading-relaxed">
            Eşleşmeleri her onayladığınızda veya revize ettiğinizde, yapay zeka saha dinamiklerini (kimin kiminle daha uyumlu çalıştığını, yetkinliklerdeki artış ve genel shift yoğunluğunu) biraz daha iyi öğrenerek sonraki eşleşmelerin <strong>Başarı Tahmin Skorunu (Match Score)</strong> %90'ın üzerine taşır.
          </p>
        </div>
      </div>
    </div>
  );
}
