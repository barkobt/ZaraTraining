import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Check, BookOpen, AlertCircle, Award, Target, Search, BookText, Archive } from "lucide-react";
import { Employee } from "../types";
import { MOCK_EMPLOYEES } from "../mockData";
import DigitalArchive from "./DigitalArchive";

type Level = "Baslangic" | "Orta" | "Ileri";
type Status = "Teorik" | "Yapabiliyor" | "Gelistirilmeli" | "Ogretebilir" | "Bos";

interface Topic {
  id: string;
  category: string;
  title: string;
  status: Status;
}

const INITIAL_TOPICS: Topic[] = [
  { id: "1", category: "Müşteri", title: "Çalışan enerjisi ve pozitif mağaza tutumu", status: "Bos" },
  { id: "2", category: "Müşteri", title: "Müşteri türleri ve CX (müşteri deneyimi) projesinin önemi", status: "Bos" },
  { id: "3", category: "Ürün", title: "Departmanlar ve buyer'lar", status: "Bos" },
  { id: "4", category: "Ürün", title: "Etiket okuma ve ürün içerik bilgisi", status: "Bos" },
  { id: "5", category: "Süreçler", title: "Askılama ve askı türleri", status: "Bos" },
  { id: "6", category: "Süreçler", title: "Sprinter / Runner sistemi (360°)", status: "Bos" },
];

const GLOSSARY_TERMS = [
  { term: "ASA", type: "Kavram", definition: "Ana Sorumluluk Alanı. Bir çalışanın mağaza içerisindeki temel görev tanımı ve performans kriterlerinin bütünü." },
  { term: "Shadowing", type: "Pedagoji", definition: "Yeni çalışanın, tecrübeli bir takım arkadaşını gün boyunca saha operasyonunda izleyerek süreçleri doğal akışında öğrenmesi." },
  { term: "Reverse Mentoring", type: "Pedagoji", definition: "Yeni nesil (veya yeni başlayan) çalışanların, teknoloji veya trend adaptasyonu gibi konularda tecrübeli yöneticilere kendi perspektiflerini aktarması." },
  { term: "One Store", type: "Kavram", definition: "Mağazada tüm kanalların (online, depo, kasa, reyon) izole olmadan entegre biçimde işlemesi prensibi." },
  { term: "Buz Kırıcı", type: "Araç", definition: "Koçluk seansının veya vardiya başı toplantısının başında iletişimi yumuşatmak için kullanılan açık uçlu, rahatlatıcı sorular." },
  { term: "Active Listening", type: "Pedagoji", definition: "Çalışanı dinlerken tamamen sürece odaklanıp, yargılamadan anlamaya çalışma durumu ve beden diliyle geribildirim verme." },
  { term: "Drop-off Çıkış", type: "Operasyon", definition: "Müşterinin online sipariş iadelerini mağaza kasasına bırakması süreçlerinin bütünü." },
];

export default function GuidebookView() {
  const [viewMode, setViewMode] = useState<"book" | "glossary" | "archive">("book");
  const [selectedRole, setSelectedRole] = useState<string>("Satış Danışmanı");
  const [activeLevel, setActiveLevel] = useState<Level>("Baslangic");
  const [topics, setTopics] = useState<Topic[]>(INITIAL_TOPICS);
  const [selectedEmp, setSelectedEmp] = useState<Employee>(MOCK_EMPLOYEES[0]);
  const [searchQuery, setSearchQuery] = useState("");

  const toggleStatus = (topicId: string, newStatus: Status) => {
    setTopics(prev => prev.map(t => 
      t.id === topicId ? { ...t, status: t.status === newStatus ? 'Bos' : newStatus } : t
    ));
  };

  const filteredTerms = GLOSSARY_TERMS.filter(item => 
    item.term.toLowerCase().includes(searchQuery.toLowerCase()) || 
    item.definition.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const StatusIcon = ({ status, active }: { status: Status, active: boolean }) => {
    const baseClasses = `w-8 h-8 rounded-full border flex items-center justify-center transition-all ${active ? 'opacity-100 scale-105' : 'opacity-30 border-dashed hover:opacity-60'}`;
    
    switch (status) {
      case "Teorik":
        return <div className={`${baseClasses} ${active ? 'bg-ink border-ink text-canvas' : 'border-ink text-ink'}`} title="Teorik"><BookOpen size={14} /></div>;
      case "Yapabiliyor":
        return <div className={`${baseClasses} ${active ? 'bg-green-700 border-green-700 text-canvas' : 'border-green-700 text-green-700'}`} title="Yapabiliyor"><Check size={14} /></div>;
      case "Gelistirilmeli":
        return <div className={`${baseClasses} ${active ? 'bg-amber-600 border-amber-600 text-canvas' : 'border-amber-600 text-amber-600'}`} title="Geliştirilmeli"><AlertCircle size={14} /></div>;
      case "Ogretebilir":
        return <div className={`${baseClasses} ${active ? 'bg-blue-600 border-blue-600 text-canvas' : 'border-blue-600 text-blue-600'}`} title="Öğretebilir"><Award size={14} /></div>;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-12 pb-24">
      <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-ink pb-8 gap-8">
        <div>
          <div className="label-caps opacity-40 mb-2 italic">Volume 02: La Documentation</div>
          <h2 className="font-serif text-5xl font-bold tracking-tighter uppercase">GELİŞİM VE TAKİP<br/>KİTAPÇIĞI</h2>
        </div>
        
        <div className="flex flex-wrap items-center gap-2 md:gap-4 bg-canvas p-1 border border-ink/20">
          <button 
            onClick={() => setViewMode("book")}
            className={`flex items-center gap-2 px-4 py-2 label-caps transition-all ${viewMode === "book" ? "bg-ink text-canvas" : "text-ink hover:bg-ink/5"}`}
          >
            <BookOpen size={16} /> Takip
          </button>
          <button 
            onClick={() => setViewMode("glossary")}
            className={`flex items-center gap-2 px-4 py-2 label-caps transition-all ${viewMode === "glossary" ? "bg-ink text-canvas" : "text-ink hover:bg-ink/5"}`}
          >
            <BookText size={16} /> Sözlük
          </button>
          <button 
            onClick={() => setViewMode("archive")}
            className={`flex items-center gap-2 px-4 py-2 label-caps transition-all ${viewMode === "archive" ? "bg-ink text-canvas" : "text-ink hover:bg-ink/5"}`}
          >
            <Archive size={16} /> Dijital Arşiv
          </button>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {viewMode === "book" ? (
          <motion.div 
            key="book"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-12"
          >
            <div className="flex flex-col md:flex-row justify-between gap-8 border-b border-border pb-4">
              <div className="flex gap-4 overflow-x-auto">
                {['Kasa Ekibi', 'Operasyon Ekibi', 'Satış Danışmanı'].map(role => (
                  <button
                    key={role}
                    onClick={() => setSelectedRole(role)}
                    className={`label-caps px-4 py-2 shrink-0 transition-all ${
                      selectedRole === role ? 'bg-ink text-canvas' : 'border border-border text-ink hover:border-ink/50'
                    }`}
                  >
                    {role}
                  </button>
                ))}
              </div>
              
              <select 
                value={selectedEmp.name}
                onChange={(e) => setSelectedEmp(MOCK_EMPLOYEES.find(emp => emp.name === e.target.value) || MOCK_EMPLOYEES[0])}
                className="bg-transparent border border-ink/20 label-caps px-4 py-2 outline-none w-full md:w-auto"
              >
                {MOCK_EMPLOYEES.map(emp => (
                  <option key={emp.id} value={emp.name}>{emp.name}</option>
                ))}
              </select>
            </div>

            <div className="art-card">
              <div className="flex border-b border-border">
                {(["Baslangic", "Orta", "Ileri"] as Level[]).map((level) => (
                  <button 
                    key={level}
                    onClick={() => setActiveLevel(level)}
                    className={`flex-1 py-4 label-caps transition-all ${
                      activeLevel === level ? 'bg-ink text-canvas border-b-2 border-ink' : 'opacity-40 hover:opacity-100 hover:bg-ink/5'
                    }`}
                  >
                    {level === 'Baslangic' ? 'Başlangıç (1-4 Hafta)' : level === 'Orta' ? 'Orta (5-6 Hafta)' : 'İleri (7-8 Hafta)'}
                  </button>
                ))}
              </div>

              <div className="p-8">
                <div className="flex items-center justify-between mb-8 opacity-40">
                  <div className="label-caps">Konu / İçerik</div>
                  <div className="label-caps hidden md:flex items-center gap-8 mr-4">
                    <span>Teorik</span>
                    <span>Uyguluyor</span>
                    <span>Gelişmeli</span>
                    <span>Öğretir</span>
                  </div>
                </div>

                <div className="space-y-4">
                  {topics.map((topic, i) => (
                    <motion.div
                      key={topic.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="flex flex-col md:flex-row md:items-center justify-between p-4 border border-border hover:border-ink/20 transition-colors group"
                    >
                      <div className="flex flex-col mb-4 md:mb-0">
                        <span className="label-caps !text-[9px] opacity-40 mb-1">{topic.category}</span>
                        <span className="font-serif text-lg">{topic.title}</span>
                      </div>
                      
                      <div className="flex items-center gap-6 justify-between md:justify-end">
                        <button onClick={() => toggleStatus(topic.id, 'Teorik')}>
                          <StatusIcon status="Teorik" active={topic.status === 'Teorik'} />
                        </button>
                        <button onClick={() => toggleStatus(topic.id, 'Yapabiliyor')}>
                          <StatusIcon status="Yapabiliyor" active={topic.status === 'Yapabiliyor'} />
                        </button>
                        <button onClick={() => toggleStatus(topic.id, 'Gelistirilmeli')}>
                          <StatusIcon status="Gelistirilmeli" active={topic.status === 'Gelistirilmeli'} />
                        </button>
                        <button onClick={() => toggleStatus(topic.id, 'Ogretebilir')}>
                          <StatusIcon status="Ogretebilir" active={topic.status === 'Ogretebilir'} />
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="flex justify-end">
              <button className="bg-ink text-canvas px-8 py-4 label-caps flex items-center gap-3 hover:bg-ink/90 transition-all">
                <Target size={16} /> Durumu Kaydet & Değerlendir
              </button>
            </div>
          </motion.div>
        ) : viewMode === "glossary" ? (
          <motion.div 
            key="glossary"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-8"
          >
            <div className="flex items-center gap-2 border-b border-ink/20 pb-4">
              <Search size={20} className="opacity-40" />
              <input 
                type="text" 
                placeholder="Terim veya kelime arayın..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-transparent outline-none font-serif text-2xl italic placeholder:opacity-30"
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <AnimatePresence>
                {filteredTerms.map((item, i) => (
                  <motion.div 
                    key={item.term}
                    layout
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="art-card p-6 flex flex-col group cursor-pointer hover:border-ink/40 transition-colors"
                  >
                    <div className="flex justify-between items-start mb-4">
                      <h3 className="font-serif text-2xl font-bold">{item.term}</h3>
                      <span className="label-caps !text-[8px] bg-ink/5 px-2 py-1 rounded-sm">{item.type}</span>
                    </div>
                    <p className="font-serif italic opacity-80 leading-relaxed text-sm group-hover:opacity-100 transition-opacity">
                      {item.definition}
                    </p>
                  </motion.div>
                ))}
              </AnimatePresence>
              
              {filteredTerms.length === 0 && (
                <div className="col-span-full py-12 text-center font-serif italic opacity-40">
                  Aramanızla eşleşen hiçbir terim bulunamadı.
                </div>
              )}
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="archive"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
          >
            <DigitalArchive employee={selectedEmp} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
