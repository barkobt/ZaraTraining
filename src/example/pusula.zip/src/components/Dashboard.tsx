import { motion } from "motion/react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Legend 
} from 'recharts';
import { Employee, SkillStatus } from "../types";
import AIGrowthAdvisor from "./AIGrowthAdvisor";
import EmployeeRadarChart from "./EmployeeRadarChart";

interface DashboardProps {
  employees: Employee[];
}

export default function Dashboard({ employees }: DashboardProps) {
  // Generate projection data
  const extendedData = employees.map(emp => {
    const tendency = [...emp.tendency];
    const lastValue = tendency[tendency.length - 1];
    const prevValue = tendency.length > 1 ? tendency[tendency.length - 2] : lastValue;
    const slope = Math.max(0, lastValue - prevValue); // Positive slope assumption
    
    return {
      ...emp,
      forecast: [
        lastValue, 
        Math.min(5, lastValue + slope * 0.8 + 0.1),
        Math.min(5, lastValue + slope * 1.5 + 0.2),
        Math.min(5, lastValue + slope * 2.0 + 0.3)
      ]
    };
  });

  // periodIndex 0-3: historical (Q1-Q4)
  // periodIndex 3-6: forecast (Ay+1, Ay+2, Ay+3)
  const chartData = [
    { name: "Q1" },
    { name: "Q2" },
    { name: "Q3" },
    { name: "Güncel" },
    { name: "+1 Ay" },
    { name: "+2 Ay" },
    { name: "+3 Ay" },
  ].map((base, i) => {
    const entry: any = { ...base };
    
    extendedData.forEach(emp => {
      if (i <= 3) {
        entry[emp.name] = emp.tendency[i];
      }
      if (i >= 3) {
        entry[`${emp.name} (Projeksiyon)`] = emp.forecast[i - 3];
      }
    });

    return entry;
  });

  const colors = ['#1A1A1A', '#A39D8D', '#E0DBCF', '#6B6B6B'];

  return (
    <div className="space-y-24">
      <div className="grid grid-cols-12 gap-8 items-end relative">
        <div className="col-span-8">
          <div className="label-caps italic opacity-50 mb-4 tracking-[0.5em]">Volume 01: L'Esprit</div>
          <h1 className="text-[120px] leading-[0.8] tracking-tighter mb-8 font-serif uppercase">
            YAŞAYAN<br/>
            <span className="pl-16 serif-italic opacity-80">UZMAN</span>
          </h1>
          <p className="max-w-md font-sans text-sm leading-relaxed opacity-80 border-l border-ink/20 pl-6">
            Gelişimin sürekliliği üzerine akademik bir vizyon. Verinin sezgiyle, planın icrayla buluştuğu nokta: <span className="font-bold">Herkes gelişir.</span>
          </p>
        </div>
        <div className="col-span-4 flex flex-col items-end">
          <div className="art-card aspect-square w-full max-w-[240px] flex flex-col justify-between">
            <div className="label-caps text-center opacity-60">Seviye Özeti</div>
            <div className="text-center font-serif text-4xl italic">{employees.length}</div>
            <div className="text-[10px] text-center opacity-40">Aktif Profil</div>
          </div>
        </div>
      </div>

      {/* Competency Chart Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="art-card p-12 flex flex-col items-center">
          <div className="w-full mb-8">
             <div className="label-caps opacity-40 mb-2 italic">Analyse</div>
             <h2 className="font-serif text-3xl mb-2">Gelişim Alanları Radarı</h2>
             <p className="text-xs opacity-60 italic">Ekip üyelerinin temel alanlardaki mevcut hakimiyetleri.</p>
          </div>
          <EmployeeRadarChart employees={employees} />
        </div>

        <div className="art-card p-12">
          <div className="flex justify-between items-start mb-12">
            <div>
              <div className="label-caps opacity-40 mb-2 italic">Evolution</div>
              <h2 className="font-serif text-3xl mb-2">Gelişim Eğrisi</h2>
              <p className="text-xs opacity-60 italic">Dönemlere göre genel tecrübe seyri.</p>
            </div>
          </div>
          <div className="h-[400px] w-full font-serif">
            <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#eee" vertical={false} />
              <XAxis 
                dataKey="name" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fontSize: 10, fontFamily: 'Inter', fontWeight: 600, opacity: 0.4 }} 
              />
              <YAxis 
                axisLine={false} 
                tickLine={false} 
                domain={[0, 5]} 
                tick={{ fontSize: 10, fontFamily: 'Inter', fontWeight: 600, opacity: 0.4 }} 
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#F5F2ED', 
                  border: '1px solid #1A1A1A', 
                  borderRadius: '0px',
                  fontFamily: 'Playfair Display',
                  fontSize: '12px'
                }} 
              />
              <Legend 
                verticalAlign="top" 
                align="right" 
                iconType="circle"
                wrapperStyle={{ 
                  paddingBottom: '40px', 
                  fontSize: '10px', 
                  fontFamily: 'Inter', 
                  fontWeight: 700, 
                  textTransform: 'uppercase', 
                  letterSpacing: '0.1em' 
                }} 
              />
              {employees.flatMap((emp, index) => [
                <Line 
                  key={`hist-${emp.id}`} 
                  type="monotone" 
                  dataKey={emp.name} 
                  stroke={colors[index % colors.length]} 
                  strokeWidth={2}
                  dot={{ r: 4, strokeWidth: 2, fill: '#F5F2ED' }}
                  activeDot={{ r: 6 }}
                  animationDuration={1500}
                />,
                <Line 
                  key={`proj-${emp.id}`} 
                  type="monotone" 
                  dataKey={`${emp.name} (Projeksiyon)`} 
                  stroke={colors[index % colors.length]} 
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  dot={{ r: 3, strokeWidth: 2, fill: '#F5F2ED', strokeDasharray: '0' }}
                  activeDot={{ r: 5 }}
                  animationDuration={1500}
                  legendType="none"
                />
              ])}
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
      </div>

      <AIGrowthAdvisor employees={employees} />

      {/* Skill Gaps Analysis */}
      <div className="art-card p-12">
        <div className="flex justify-between items-end mb-12">
          <div>
            <div className="label-caps opacity-40 mb-2 italic">Diagnosis</div>
            <h2 className="font-serif text-3xl mb-2">Gelişim Açığı Analizi</h2>
            <p className="text-sm opacity-60 italic max-w-xl">
              Rol beklentilerine göre en acil eğitim ihtiyacı duyan yetkinlik başlıkları ve ilgili ekip üyeleri.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {Object.entries(
            employees.reduce((acc, emp) => {
              emp.skills.forEach(skill => {
                if (skill.status === SkillStatus.Theory || skill.status === SkillStatus.NeedImprovement) {
                  if (!acc[skill.topic]) acc[skill.topic] = { count: 0, employees: [] };
                  acc[skill.topic].count += 1;
                  if (!acc[skill.topic].employees.includes(emp.name)) {
                    acc[skill.topic].employees.push(emp.name);
                  }
                }
              });
              return acc;
            }, {} as Record<string, { count: number, employees: string[] }>)
          )
            .map(([topic, data]) => ({ topic, ...data }))
            .sort((a, b) => b.count - a.count)
            .slice(0, 4)
            .map((gap, i) => (
            <div key={gap.topic} className="border-t border-ink pt-6 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-2 h-2 bg-ink rounded-full" />
                  <span className="label-caps !text-[10px] opacity-60">Öncelikli Başlık</span>
                </div>
                <h3 className="font-serif text-xl mb-4 leading-tight">{gap.topic}</h3>
                <div className="space-y-1 mb-8">
                  {gap.employees.map(name => (
                    <div key={name} className="text-xs opacity-70 italic font-serif flex items-center gap-2">
                       <span className="w-1 h-1 bg-ink/30 rounded-full" />
                       {name}
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex items-end justify-between border-t border-ink/10 pt-4">
                <span className="label-caps !text-[9px] opacity-40">Kişi Etkileniyor</span>
                <span className="font-serif text-3xl italic leading-none">{gap.count}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Peer Encouragement Flow */}
      <div className="art-card p-12">
        <div className="flex justify-between items-end mb-12">
          <div>
            <div className="label-caps opacity-40 mb-2 italic">Culture</div>
            <h2 className="font-serif text-3xl mb-2">Gelişim Teşvik Akışı</h2>
            <p className="text-sm opacity-60 italic max-w-xl">
              Ekip üyelerinin birbirlerinin gelişimini desteklemek için paylaştıkları anlık geri bildirimler ve motivasyon notları.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2 space-y-6">
            {[
              { from: "Baran B.", to: "Deniz Y.", note: "Reyon düzenindeki detaycılığın dün mağaza genelinde mükemmel bir sunum yarattı.", date: "Bugün, 14:30" },
              { from: "Ayşe A.", to: "Baran B.", note: "Yoğun saatlerdeki sakinliğin ve ekibi yönlendirmen gerçekten bana çok yardımcı oldu.", date: "Dün, 16:45" },
              { from: "Selin Y.", to: "Ayşe A.", note: "Müşteri ile kurduğun empati ve çözüm odaklı yaklaşım hepimize örnek oldu.", date: "12 Haziran" },
            ].map((kudos, i) => (
              <div key={i} className="flex gap-6 border-b border-border pb-6 last:border-0">
                <div className="w-10 h-10 shrink-0 rounded-full border border-ink flex items-center justify-center font-serif italic text-sm">
                  {kudos.from.charAt(0)}
                </div>
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <span className="label-caps !text-[10px]">{kudos.from}</span>
                    <span className="opacity-40 text-xs">&rarr;</span>
                    <span className="label-caps !text-[10px]">{kudos.to}</span>
                    <span className="label-caps !text-[9px] opacity-40 ml-2">{kudos.date}</span>
                  </div>
                  <p className="font-serif italic text-lg leading-relaxed opacity-80">
                    "{kudos.note}"
                  </p>
                </div>
              </div>
            ))}
          </div>
          
          <div className="flex flex-col justify-between border-t lg:border-t-0 lg:border-l border-ink/10 pt-8 lg:pt-0 lg:pl-12">
            <div>
               <div className="label-caps opacity-40 mb-4">Motivasyon Etkisi</div>
               <div className="text-6xl font-serif mb-4 leading-none">+24%</div>
               <p className="text-sm font-serif opacity-60 italic">Bu ay içinde paylaşılan teşvik notlarının genel takım motivasyonu anketlerine pozitif yansıması.</p>
            </div>
            
            <div className="mt-12">
              <div className="label-caps opacity-40 mb-4">Ayın En Çok Teşvik Alanı</div>
              <div className="flex items-center gap-4">
                 <div className="w-12 h-12 rounded-full bg-ink text-canvas flex items-center justify-center font-serif italic text-xl">
                   B
                 </div>
                 <div>
                   <div className="font-bold font-serif text-lg">Baran B.</div>
                   <div className="text-xs opacity-60 font-serif italic">8 Teşvik Notu</div>
                 </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          { label: "Güçlü Yan", title: "Müşteri Servisi", desc: "Conversion Lift ortalaması geçen haftaya göre +12% arttı.", color: "bg-ink" },
          { label: "Tıkanıklık", title: "One Store", desc: "6 ekip üyesinde bu konu 'Geliştirilmeli' seviyesinde.", color: "bg-transparent border border-ink" },
          { label: "AI Vizyon", title: "Usta Aktarımı", desc: "Selin Yılmaz bu hafta yeni 'Öğretme Kartı' çıkarabilir.", color: "bg-[#E0DBCF]" },
        ].map((item, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="art-card flex flex-col justify-between aspect-[4/5]"
          >
            <div>
              <div className="label-caps mb-8 opacity-40">{item.label}</div>
              <h3 className="text-3xl font-serif mb-4 leading-tight">{item.title}</h3>
              <p className="text-sm opacity-60 leading-relaxed italic">{item.desc}</p>
            </div>
            <div className={`w-8 h-8 rounded-full ${item.color}`}></div>
          </motion.div>
        ))}
      </div>

      <div className="border-t border-ink pt-16">
        <h3 className="label-caps mb-12">Aktif Gelişim Arşivi</h3>
        <div className="grid grid-cols-1 gap-[1px] bg-border border border-border">
          {employees.map((emp) => (
            <div key={emp.id} className="flex items-center justify-between p-8 bg-canvas hover:bg-white transition-colors group">
              <div className="flex items-center gap-12">
                <div className="w-16 h-16 rounded-full border border-ink flex items-center justify-center font-serif italic text-xl group-hover:bg-ink group-hover:text-canvas transition-all">
                  0{emp.id}
                </div>
                <div>
                  <div className="label-caps text-xs mb-1">{emp.name}</div>
                  <div className="font-serif italic text-lg opacity-60">{emp.level}</div>
                </div>
              </div>
              <div className="hidden md:block">
                <div className="label-caps opacity-30 mb-1">Odak</div>
                <div className="text-sm font-bold tracking-tight">{emp.growthEdge}</div>
              </div>
              <div className="text-right">
                <div className="text-[32px] font-serif italic">{(emp.tendency[emp.tendency.length - 1] * 20)}%</div>
                <div className="label-caps opacity-40">Gelişim İndeksi</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
