import { motion } from "motion/react";
import { Calendar, Clock, MapPin, Users } from "lucide-react";
import { MOCK_AGENDA } from "../mockData";

export default function AgendaView() {
  return (
    <div className="space-y-12">
      <div className="flex items-end justify-between border-b border-ink pb-8">
        <div>
          <div className="label-caps opacity-40 mb-2 italic">Volume 01: Le Temps</div>
          <h2 className="font-serif text-5xl font-bold tracking-tighter uppercase">GELİŞİM<br/>AJANDASI</h2>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {MOCK_AGENDA.map((item, i) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
            className="art-card flex flex-col md:flex-row gap-8 items-start md:items-center relative"
          >
            <div className="flex flex-col items-center justify-center p-6 bg-ink text-canvas rounded-none w-full md:w-32 aspect-square">
              <div className="label-caps !text-[14px] !tracking-normal mb-1">{item.date.split(' ')[1]}</div>
              <div className="font-serif text-4xl font-bold leading-none">{item.date.split(' ')[0]}</div>
            </div>

            <div className="flex-1 space-y-4">
              <div className="flex items-center gap-4">
                <span className="label-caps text-[9px] px-2 py-0.5 border border-ink/20 italic">{item.type}</span>
                <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-widest opacity-40">
                  <Clock size={12} />
                  {item.time}
                </div>
              </div>
              <h3 className="font-serif text-3xl italic tracking-tight">{item.title}</h3>
              
              <div className="flex flex-wrap gap-6 text-[10px] uppercase tracking-[0.2em] font-bold opacity-60">
                <div className="flex items-center gap-2">
                  <Users size={14} className="opacity-40" />
                  {item.participants.join(', ')}
                </div>
                <div className="flex items-center gap-2">
                  <MapPin size={14} className="opacity-40" />
                  {item.location}
                </div>
              </div>
            </div>

            <div className="absolute right-8 top-8 opacity-5">
               <Calendar size={120} strokeWidth={1} />
            </div>
          </motion.div>
        ))}
      </div>

      <div className="p-12 border border-dashed border-ink/20 flex flex-col items-center text-center gap-6">
        <div className="label-caps opacity-40">Yeni Etkinlik</div>
        <p className="font-serif italic text-xl opacity-60">Bir sonraki vizyon seansını buraya ekleyin.</p>
        <button className="w-12 h-12 rounded-full border border-ink flex items-center justify-center hover:bg-ink hover:text-canvas transition-all">
          +
        </button>
      </div>
    </div>
  );
}
