import { motion } from "motion/react";
import { Sparkles, ArrowRight, Zap, Target, BookOpen } from "lucide-react";
import { Employee, MasteryLevel } from "../types";

interface AIGrowthAdvisorProps {
  employees: Employee[];
}

export default function AIGrowthAdvisor({ employees }: AIGrowthAdvisorProps) {
  const getRecommendation = (emp: Employee) => {
    const score = emp.tendency[emp.tendency.length - 1];
    
    if (emp.level === MasteryLevel.Coach) {
      return {
        title: "Dönüşümsel Liderlik",
        desc: "Ekip geneline yayılan 'One Store' vizyonu için koçluk metodolojisinde derinleşme.",
        icon: <Zap size={18} />,
        impact: "Kültürel Dönüşüm"
      };
    }
    
    if (score > 4) {
      return {
        title: "Usta Aktarımı (Mentorship)",
        desc: "Bireysel başarıyı çarpan etkisine dönüştürmek için yeni adaylara mentorluk seansı.",
        icon: <Target size={18} />,
        impact: "Ekip Yetkinlik Artışı"
      };
    }
    
    if (score < 2.5) {
      return {
        title: "Teorik Temel Pekiştirme",
        desc: "Saha operasyonundan önce temel ilkelerin (ASA) teorik sınavlarla doğrulanması.",
        icon: <BookOpen size={18} />,
        impact: "Hata Payı Azaltımı"
      };
    }

    return {
      title: "Operasyonel Derinlik",
      desc: "Mevcut satış kabiliyetini depo ve sistem entegrasyonu ile uçtan uca yönetme.",
      icon: <Sparkles size={18} />,
      impact: "Süreç Verimliliği"
    };
  };

  return (
    <div className="space-y-12">
      <div className="flex items-center gap-4">
        <div className="w-10 h-10 rounded-full bg-ink flex items-center justify-center text-canvas">
          <Sparkles size={18} />
        </div>
        <div>
          <div className="label-caps opacity-40">AI Engine V1.0</div>
          <h2 className="font-serif text-3xl italic underline decoration-border underline-offset-8">Gelişim Tezi Önerileri</h2>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {employees.map((emp, i) => {
          const rec = getRecommendation(emp);
          return (
            <motion.div
              key={emp.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.1 }}
              className="art-card flex flex-col justify-between group cursor-help"
            >
              <div>
                <div className="flex items-center justify-between mb-8">
                  <div className="w-10 h-10 rounded-full border border-ink/10 flex items-center justify-center opacity-60">
                    {rec.icon}
                  </div>
                  <div className="label-caps !text-[8px] opacity-40">{emp.name.split(' ')[0]} için</div>
                </div>
                
                <h3 className="font-serif text-2xl mb-4 leading-tight group-hover:italic transition-all">
                  {rec.title}
                </h3>
                <p className="text-xs opacity-60 leading-relaxed italic border-l border-ink/10 pl-4 py-1">
                  "{rec.desc}"
                </p>
              </div>

              <div className="mt-12 pt-8 border-t border-border flex items-center justify-between group-hover:border-ink/30 transition-colors">
                <div className="flex flex-col">
                  <span className="label-caps opacity-30 !text-[7px]">Tahmini Etki</span>
                  <span className="text-[10px] font-bold uppercase tracking-widest">{rec.impact}</span>
                </div>
                <button className="p-2 rounded-full border border-ink/5 group-hover:border-ink/40 group-hover:bg-ink group-hover:text-canvas transition-all">
                  <ArrowRight size={14} />
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
