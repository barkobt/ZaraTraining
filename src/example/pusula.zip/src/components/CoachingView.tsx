import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { MessageSquare, Target, User, Lightbulb, PlayCircle, Users } from "lucide-react";
import { AreaChart, Area, XAxis, Tooltip, ResponsiveContainer, ComposedChart, Bar, Line, YAxis } from 'recharts';
import { Employee, MasteryLevel } from "../types";
import { MOCK_EMPLOYEES } from "../mockData";
import MentorMatrix from "./MentorMatrix";

export default function CoachingView() {
  const [viewMode, setViewMode] = useState<"individual" | "matrix">("individual");
  const [selectedEmp, setSelectedEmp] = useState<Employee>(MOCK_EMPLOYEES[1]);
  const [activeStep, setActiveStep] = useState<"prepare" | "simulate" | "journal">("prepare");
  const [newEntry, setNewEntry] = useState("");
  const [suggestions, setSuggestions] = useState<Record<string, string>>({});
  const [loadingSuggestions, setLoadingSuggestions] = useState<Record<string, boolean>>({});

  const handleSuggestStep = async (entryId: string, note: string) => {
    setLoadingSuggestions(prev => ({ ...prev, [entryId]: true }));
    try {
      const res = await fetch("/api/suggest-step", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ note })
      });
      const data = await res.json();
      if (data.suggestion) {
        setSuggestions(prev => ({ ...prev, [entryId]: data.suggestion }));
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingSuggestions(prev => ({ ...prev, [entryId]: false }));
    }
  };

  const getCoachingPlan = (emp: Employee) => {
    const isNew = emp.level === MasteryLevel.New;
    
    return {
      objective: isNew 
        ? "Temel operasyonel süreçlerin içselleştirilmesi ve saha özgüveninin inşası."
        : "Mevcut deneyimin uzmanlığa dönüştürülmesi ve yeni takım arkadaşlarına aktarımı.",
      approach: isNew
        ? "Yönlendirici ve Destekleyici (Guidance & Support). İlk haftalarda bolca onaylama ve küçük başarıları kutlama."
        : "Katılımcı ve Yetkilendirici (Delegation). Kendi çözümlerini bulması için 'açık uçlu' sorular sorma.",
      starters: isNew 
        ? [
          "İlk haftanda sahadaki tempo sana nasıl hissettirdi?",
          "En çok hangi konuda destek aradığını hissediyorsun?",
          "Şu anki hedeflerimizden hangisi sana daha zorlayıcı geliyor?"
        ]
        : [
          "Son dönemde ekibe senin uzmanlığından daha fazla nasıl fayda sağlayabiliriz?",
          "Usta aktarımı yaparken en çok hangi aşamada zorlanıyorsun?",
          "Sence mağaza içindeki 'One Store' operasyonlarında neleri iyileştirebiliriz?"
        ],
      scenario: {
        title: isNew ? "Yoğun Saat (Tepe Saat) Kasa Simülasyonu" : "Rehberlik ve Geri Bildirim Simülasyonu",
        context: isNew
          ? "Müşteri sırası uzamaya başlıyor ve yeni bir işlem tipinde (parçalı iade) nasıl ilerleyeceğinden emin değilsin. Ben müşteri olacağım."
          : "Yeni bir ekip arkadaşımız, müşteri yaklaşımında zorlanıyor. Ona reyon içerisinde anlık, yapıcı bir geri bildirim vermeni isteyeceğim. Ben yeni arkadaşımız olacağım.",
        coachRole: "Senin görevin, durumu analiz edip doğru aksiyonu almak ve nerede yardıma ihtiyacın olduğunu net ifade etmek.",
      }
    };
  };

  const plan = getCoachingPlan(selectedEmp);

  return (
    <div className="space-y-12 pb-24">
      <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-ink pb-8 gap-8">
        <div>
          <div className="label-caps opacity-40 mb-2 italic">Volume 01: La Guidance</div>
          <h2 className="font-serif text-5xl font-bold tracking-tighter uppercase">KOÇLUK<br/>SİMÜLASYONU</h2>
        </div>
        
        <div className="flex items-center gap-4 bg-canvas p-1 border border-ink/20 shrink-0">
          <button 
            onClick={() => setViewMode("individual")}
            className={`flex items-center gap-2 px-4 py-2 label-caps transition-all ${viewMode === "individual" ? "bg-ink text-canvas" : "text-ink hover:bg-ink/5"}`}
          >
            <User size={16} /> Bireysel Koçluk
          </button>
          <button 
            onClick={() => setViewMode("matrix")}
            className={`flex items-center gap-2 px-4 py-2 label-caps transition-all ${viewMode === "matrix" ? "bg-ink text-canvas" : "text-ink hover:bg-ink/5"}`}
          >
            <Users size={16} /> Mentorluk Matrisi
          </button>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {viewMode === "individual" ? (
          <motion.div 
            key="individual"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="grid grid-cols-1 lg:grid-cols-12 gap-12"
          >
            {/* Selection Sidebar */}
        <div className="lg:col-span-4 space-y-6 flex flex-col">
          <div className="label-caps opacity-40 mb-2">Simülasyon Hedefini Seç</div>
          <div className="flex flex-col gap-2">
            {MOCK_EMPLOYEES.map((emp) => (
              <button
                key={emp.id}
                onClick={() => setSelectedEmp(emp)}
                className={`p-6 text-left border transition-all ${
                  selectedEmp.id === emp.id
                    ? "border-ink bg-ink text-canvas shadow-xl"
                    : "border-border bg-transparent hover:border-ink/30 text-ink"
                }`}
              >
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-full border flex items-center justify-center font-serif italic text-lg ${
                    selectedEmp.id === emp.id ? "border-canvas" : "border-ink"
                  }`}>
                    {emp.name[0]}
                  </div>
                  <div>
                    <h3 className="font-serif text-xl font-bold tracking-tight">{emp.name}</h3>
                    <div className={`label-caps mt-1 ${selectedEmp.id === emp.id ? 'opacity-80' : 'opacity-40'}`}>
                      {emp.level}
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>

          {/* Coaching Efficiency Chart */}
          <div className="art-card p-6 mt-8">
            <div className="label-caps opacity-40 mb-4">Koçluk Efor Grafiği</div>
            <div className="h-40 w-full font-serif">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={[
                  { name: '1. Hft', Efor: 2 },
                  { name: '2. Hft', Efor: 3 },
                  { name: '3. Hft', Efor: 1 },
                  { name: '4. Hft', Efor: 5 },
                  { name: '5. Hft', Efor: 2 },
                ]} margin={{ top: 5, right: 0, left: 0, bottom: 0 }}>
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 9, fontFamily: 'Inter', opacity: 0.4 }} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#F5F2ED', border: '1px solid #1A1A1A', fontSize: '10px', borderRadius: '0' }}
                  />
                  <Area type="step" dataKey="Efor" stroke="#1A1A1A" fill="#1A1A1A" fillOpacity={0.1} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="text-[10px] uppercase tracking-widest opacity-60 text-center mt-4">
              Haftalık Gözlem & Geri Bildirim Yoğunluğu
            </div>
          </div>

          {/* Growth Impact Analysis */}
          <div className="art-card p-6 mt-8">
            <div className="label-caps opacity-40 mb-4">Gelişim Etki Analizi</div>
            <div className="h-40 w-full font-serif">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={[
                  { name: '1. Ç', Egitim: 8, Skor: 45 },
                  { name: '2. Ç', Egitim: 12, Skor: 58 },
                  { name: '3. Ç', Egitim: 15, Skor: 72 },
                  { name: '4. Ç', Egitim: 10, Skor: 82 },
                ]} margin={{ top: 5, right: 0, left: -25, bottom: 0 }}>
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 9, fontFamily: 'Inter', opacity: 0.4 }} />
                  <YAxis yAxisId="left" axisLine={false} tickLine={false} tick={{ fontSize: 9, fontFamily: 'Inter', opacity: 0.4 }} />
                  <YAxis yAxisId="right" orientation="right" hide />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#F5F2ED', border: '1px solid #1A1A1A', fontSize: '10px', borderRadius: '0' }}
                  />
                  <Bar yAxisId="right" dataKey="Egitim" fill="#1A1A1A" fillOpacity={0.1} barSize={16} radius={[2, 2, 0, 0]} />
                  <Line yAxisId="left" type="monotone" dataKey="Skor" stroke="#1A1A1A" strokeWidth={2} dot={{ r: 3, strokeWidth: 2, fill: '#F5F2ED' }} />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
            <div className="text-[10px] uppercase tracking-widest opacity-60 text-center mt-4 flex items-center justify-center gap-4">
              <span className="flex items-center gap-1"><span className="w-2 h-2 bg-ink/10 inline-block"></span> Eğitim Sayısı</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 bg-ink rounded-full inline-block"></span> Gelişim Skoru</span>
            </div>
          </div>
        </div>

        {/* Coaching Canvas */}
        <div className="lg:col-span-8">
          <div className="art-card relative overflow-hidden h-full flex flex-col">
            <div className="flex border-b border-border mb-8">
              <button 
                onClick={() => setActiveStep("prepare")}
                className={`flex-1 pb-4 label-caps transition-all ${activeStep === 'prepare' ? 'border-b border-ink opacity-100' : 'opacity-30 hover:opacity-80'}`}
              >
                1. Hazırlık ve Teşhis
              </button>
              <button 
                onClick={() => setActiveStep("simulate")}
                className={`flex-1 pb-4 label-caps transition-all ${activeStep === 'simulate' ? 'border-b border-ink opacity-100' : 'opacity-30 hover:opacity-80'}`}
              >
                2. Aktif Simülasyon
              </button>
              <button 
                onClick={() => setActiveStep("journal")}
                className={`flex-1 pb-4 label-caps transition-all ${activeStep === 'journal' ? 'border-b border-ink opacity-100' : 'opacity-30 hover:opacity-80'}`}
              >
                3. Gelişim Günlüğü
              </button>
            </div>

            <AnimatePresence mode="wait">
              {activeStep === "prepare" ? (
                <motion.div
                  key="prepare"
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 10 }}
                  className="space-y-8 flex-1"
                >
                  <div>
                    <h4 className="label-caps opacity-40 mb-2 flex items-center gap-2"><Target size={14} /> Gelişim Odağı</h4>
                    <p className="font-serif italic text-xl leading-relaxed">{plan.objective}</p>
                  </div>
                  
                  <div className="bg-border h-[1px] w-full" />
                  
                  <div>
                    <h4 className="label-caps opacity-40 mb-2 flex items-center gap-2"><Lightbulb size={14} /> Önerilen Koçluk Yaklaşımı</h4>
                    <p className="font-serif italic text-xl leading-relaxed opacity-80">{plan.approach}</p>
                  </div>

                  <div className="bg-border h-[1px] w-full" />

                  <div>
                    <h4 className="label-caps opacity-40 mb-4 flex items-center gap-2"><MessageSquare size={14} /> Güçlü Soru Kalıpları (Buz Kırıcılar)</h4>
                    <ul className="space-y-4">
                      {plan.starters.map((starter, i) => (
                        <li key={i} className="flex gap-4">
                          <span className="font-serif italic text-ink/40 text-lg">0{i+1}</span>
                          <span className="font-serif text-lg">"{starter}"</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </motion.div>
              ) : activeStep === "simulate" ? (
                <motion.div
                  key="simulate"
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 10 }}
                  className="flex flex-col flex-1"
                >
                  <div className="bg-ink text-canvas p-8 mb-8">
                    <div className="label-caps opacity-60 mb-2">Senaryo: {plan.scenario.title}</div>
                    <p className="font-serif text-2xl italic leading-tight">
                      "{plan.scenario.context}"
                    </p>
                  </div>

                  <div className="flex gap-6 mb-12">
                    <div className="w-12 h-12 rounded-full border border-ink flex items-center justify-center shrink-0">
                      <User size={18} />
                    </div>
                    <div>
                      <div className="label-caps opacity-40 mb-1">Coach Rolü</div>
                      <p className="text-sm font-sans opacity-80 leading-relaxed font-medium">Satış danışmanının bu senaryoda kendi sınırlarını keşfetmesine izin ver. Hemen doğru formülü söylemek yerine, <span className="font-bold underline decoration-ink/40">ne yapması gerektiğini ona buldurmaya</span> çalış.</p>
                    </div>
                  </div>

                  <div className="mt-auto pt-8 border-t border-border flex justify-between items-center">
                    <div className="label-caps opacity-40 text-[10px]">Eylem 1/1</div>
                    <button className="flex items-center gap-3 bg-ink text-canvas px-6 py-3 rounded-full label-caps hover:bg-ink/90 transition-all font-bold">
                      <PlayCircle size={16} /> Simülasyonu Başlat
                    </button>
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  key="journal"
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 10 }}
                  className="flex flex-col flex-1"
                >
                  <div className="flex-1 overflow-y-auto space-y-8 pr-4">
                    {selectedEmp.journalEntries ? (
                      selectedEmp.journalEntries.map((entry) => (
                        <div key={entry.id} className="relative pl-8 border-l border-border pb-4">
                          <div className="absolute w-2 h-2 bg-canvas border border-ink rounded-full -left-[4.5px] top-1.5" />
                          <div className="flex items-baseline justify-between mb-2">
                            <div className="label-caps !text-[10px] opacity-40">{entry.date}</div>
                            <div className="label-caps !text-[9px] opacity-30 italic">{entry.author}</div>
                          </div>
                          <p className="font-serif italic text-lg leading-relaxed opacity-90 text-ink mb-4">
                            "{entry.note}"
                          </p>
                          
                          {suggestions[entry.id] ? (
                            <div className="bg-ink/5 border border-ink/10 p-4 rounded-sm flex gap-4 mt-2">
                              <Lightbulb size={16} className="shrink-0 mt-0.5 opacity-60" />
                              <div>
                                <div className="label-caps !text-[9px] opacity-40 mb-1">AI Gelişim Önerisi</div>
                                <p className="font-serif italic text-sm">{suggestions[entry.id]}</p>
                              </div>
                            </div>
                          ) : (
                            <button 
                              onClick={() => handleSuggestStep(entry.id, entry.note)}
                              disabled={loadingSuggestions[entry.id]}
                              className="label-caps !text-[9px] px-3 py-1.5 border border-ink/20 hover:border-ink hover:bg-ink hover:text-canvas transition-all disabled:opacity-50 disabled:cursor-wait"
                            >
                              {loadingSuggestions[entry.id] ? "Analiz Ediliyor..." : "Bir Sonraki Adımı Öner"}
                            </button>
                          )}
                        </div>
                      ))
                    ) : (
                      <div className="text-center opacity-40 italic font-serif">Henüz bir gözlem girilmemiş.</div>
                    )}
                  </div>
                  
                  <div className="mt-8 pt-8 border-t border-border">
                    <div className="label-caps opacity-40 mb-4">Yeni Gözlem Notu</div>
                    <textarea 
                      value={newEntry}
                      onChange={(e) => setNewEntry(e.target.value)}
                      className="w-full bg-transparent border border-ink/20 p-4 font-serif italic text-lg outline-none focus:border-ink resize-none min-h-[100px]"
                      placeholder="Dünkü vardiyada gözlemlediğiniz gelişim ipuçları..."
                    />
                    <div className="flex justify-end mt-4">
                      <button 
                        onClick={() => setNewEntry("")}
                        className="bg-ink text-canvas px-6 py-2 rounded-full label-caps hover:bg-ink/90 transition-all font-bold"
                      >
                        Kaydet
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </motion.div>
    ) : (
      <motion.div
        key="matrix"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -10 }}
      >
        <MentorMatrix />
      </motion.div>
    )}
  </AnimatePresence>
</div>
);
}
