/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  BarChart3, 
  Users, 
  Calendar, 
  Bell,
  Search,
  BookOpen
} from "lucide-react";
import { MOCK_EMPLOYEES } from "./mockData";
import Dashboard from "./components/Dashboard";
import ProfileDetail from "./components/ProfileView";
import SolverView from "./components/SolverView";
import AgendaView from "./components/AgendaView";
import NotificationPanel from "./components/NotificationPanel";
import CoachingView from "./components/CoachingView";
import GuidebookView from "./components/GuidebookView";

export default function App() {
  const [activeTab, setActiveTab] = useState("report");
  const [selectedUser, setSelectedUser] = useState(MOCK_EMPLOYEES[0]);
  const [showNotifications, setShowNotifications] = useState(false);

  const tabs = [
    { id: "report", label: "Dashboard", icon: BarChart3 },
    { id: "competency", label: "Gelişim Profili", icon: Users },
    { id: "generate", label: "Gerekçeli Yerleştirme", icon: Calendar },
    { id: "coaching", label: "Koçluk Simülasyonu", icon: BookOpen },
    { id: "guidebook", label: "Takip Kitapçığı", icon: BookOpen },
    { id: "agenda", label: "Ajanda", icon: Calendar },
  ];

  return (
    <div className="h-screen bg-canvas flex font-sans overflow-hidden text-ink">
      {/* Sidebar Navigation */}
      <aside className="w-80 bg-canvas border-r border-border flex flex-col justify-between shrink-0 z-50 relative">
        <div className="p-12">
          <div className="flex items-center gap-4 mb-20 group cursor-pointer">
            <div className="w-12 h-12 bg-ink text-canvas font-serif text-2xl italic font-bold flex items-center justify-center rounded-none group-hover:bg-transparent group-hover:text-ink border border-ink transition-all">
              V
            </div>
            <div className="flex flex-col text-ink">
              <div className="label-caps italic opacity-60 mb-1 leading-none">Studio Pusula</div>
              <h1 className="font-serif text-2xl font-bold tracking-tight uppercase">Vizyonner</h1>
            </div>
          </div>
          
          <nav className="flex flex-col gap-6">
            <div className="label-caps opacity-30 mb-2">Modüller</div>
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-4 text-left transition-all ${
                  activeTab === tab.id ? 'opacity-100' : 'opacity-40 hover:opacity-80'
                }`}
              >
                <div className={`w-8 h-8 flex items-center justify-center ${activeTab === tab.id ? 'border border-ink rounded-full' : ''}`}>
                  <tab.icon size={16} />
                </div>
                <span className={`label-caps !tracking-[0.15em] ${activeTab === tab.id ? 'font-bold' : ''}`}>
                  {tab.label}
                </span>
              </button>
            ))}
          </nav>
        </div>

        <div className="p-12 border-t border-border flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-full border border-ink flex items-center justify-center italic text-sm font-serif">
              BB
            </div>
            <div>
              <div className="text-[11px] font-bold">Baran B.</div>
              <div className="label-caps opacity-40 !text-[8px]">Mağaza Koçu</div>
            </div>
          </div>

          <div className="relative">
            <button 
              onClick={() => setShowNotifications(!showNotifications)}
              className={`p-2 transition-all relative rounded-full ${showNotifications ? 'bg-ink text-canvas' : 'bg-border/50 text-ink hover:bg-border'}`}
            >
              <Bell size={18} />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full border-2 border-canvas"></span>
            </button>
            <AnimatePresence>
              {showNotifications && (
                <NotificationPanel onClose={() => setShowNotifications(false)} />
              )}
            </AnimatePresence>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 h-screen overflow-y-auto bg-canvas p-12 lg:p-20 relative">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className="h-full"
          >
            {activeTab === "report" && <Dashboard employees={MOCK_EMPLOYEES} />}
            
            {activeTab === "competency" && (
              <div className="space-y-12">
                <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-none border-b border-border">
                  {MOCK_EMPLOYEES.map(emp => (
                    <button
                      key={emp.id}
                      onClick={() => setSelectedUser(emp)}
                      className={`label-caps px-4 py-2 transition-all ${
                        selectedUser.id === emp.id 
                          ? 'text-ink italic border-b-2 border-ink' 
                          : 'opacity-30 hover:opacity-100'
                      }`}
                    >
                      {emp.name}
                    </button>
                  ))}
                </div>
                <ProfileDetail employee={selectedUser} />
              </div>
            )}

            {activeTab === "generate" && <SolverView employees={MOCK_EMPLOYEES} />}
            
            {activeTab === "coaching" && <CoachingView />}

            {activeTab === "guidebook" && <GuidebookView />}

            {activeTab === "agenda" && <AgendaView />}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}
