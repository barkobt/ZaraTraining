import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API route for Gemini suggestions
  app.post("/api/suggest-step", async (req, res) => {
    try {
      const { note } = req.body;
      const apiKey = process.env.GEMINI_API_KEY;
      
      if (!apiKey) {
        return res.status(500).json({ error: "GEMINI_API_KEY environment variable is missing" });
      }

      if (!note) {
        return res.status(400).json({ error: "Note is required" });
      }

      const ai = new GoogleGenAI({ apiKey });
      
      const prompt = `Sen eğitim ve perakende koçusun. Ekip üyesinin durumu hakkında girilen şu gözlem notundan yola çıkarak, bu çalışan için alması gereken somut, eyleme geçirilebilir tek bir sonraki gelişim adımını tek bir kısa cümleyle öner.

Gözlem Notu: ${note}

Öneri (maksimum 15 kelime):`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
      });

      const suggestion = response.text || "Öneri bulunamadı.";
      res.json({ suggestion: suggestion.trim() });
    } catch (error) {
      console.error("Gemini API error:", error);
      res.status(500).json({ error: "API hatası oluştu." });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
