import { Employee, Role, MasteryLevel, SkillStatus } from "./types";

export const MOCK_EMPLOYEES: Employee[] = [
  {
    id: "1",
    name: "Selin Yılmaz",
    role: Role.SalesAssistant,
    level: MasteryLevel.Competent,
    tenure: "5 Ay",
    strongPoint: "Satış & Servis (Conversion Lift)",
    growthEdge: "One Store Derinliği",
    tendency: [3.2, 3.5, 4.1, 4.2],
    asaMap: [
      { label: "Mağaza Operasyonu", weight: 25, status: "neutral" },
      { label: "Müşteri Servisi", weight: 25, status: "strong" },
      { label: "Satış", weight: 40, status: "strong" },
      { label: "Kendini Geliştirme", weight: 10, status: "developing" },
    ],
    skills: [
      { topic: "Conversion Lifts", status: SkillStatus.CanTeach, date: "2024-05-10" },
      { topic: "One Store Uçtan Uca", status: SkillStatus.NeedImprovement, date: "2024-06-01" },
      { topic: "Koleksiyon Hakimiyeti", status: SkillStatus.CanDo, date: "2024-04-15" },
    ]
  },
  {
    id: "2",
    name: "Mert Demir",
    role: Role.SalesAssistant,
    level: MasteryLevel.New,
    tenure: "3 Hafta",
    strongPoint: "Operasyonel Hız",
    growthEdge: "Satış Kapanış",
    tendency: [1.5, 2.1, 2.4, 2.6],
    asaMap: [
      { label: "Mağaza Operasyonu", weight: 30, status: "strong" },
      { label: "Müşteri Servisi", weight: 20, status: "developing" },
      { label: "Satış", weight: 20, status: "developing" },
      { label: "Kendini Geliştirme", weight: 30, status: "strong" },
    ],
    skills: [
      { topic: "Mağaza Düzeni", status: SkillStatus.CanDo, date: "2024-06-05" },
      { topic: "Müşteri Yaklaşımı", status: SkillStatus.Theory, date: "2024-06-02" },
    ]
  },
  {
    id: "3",
    name: "Baran B.",
    role: Role.SalesAssistant,
    level: MasteryLevel.Coach,
    tenure: "2 Yıl",
    strongPoint: "Ekip Yönetimi & KPI Köprüsü",
    growthEdge: "Geri Bildirim Döngüsü",
    tendency: [4.8, 4.9, 4.9, 5.0],
    asaMap: [
      { label: "Mağaza Operasyonu", weight: 25, status: "strong" },
      { label: "Müşteri Servisi", weight: 25, status: "strong" },
      { label: "Satış", weight: 25, status: "strong" },
      { label: "Kendini Geliştirme", weight: 25, status: "strong" },
    ],
    skills: [
      { topic: "Koçluk Becerileri", status: SkillStatus.CanTeach, date: "2023-12-01" },
      { topic: "KPI Analizi", status: SkillStatus.CanTeach, date: "2024-01-10" },
    ]
  }
];
