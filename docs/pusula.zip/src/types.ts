/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum Role {
  SalesAssistant = "Satış Danışmanı",
  Cashier = "Kasa",
  Operations = "Operasyon"
}

export enum MasteryLevel {
  New = "Yeni (0-2 ay)",
  Competent = "Yetkin (3 ay+)",
  Master = "Usta/Öğretebilir",
  Coach = "Koç/Eğitimci"
}

export enum SkillStatus {
  Theory = "Teorik",
  CanDo = "Yapabiliyor",
  NeedImprovement = "Geliştirilmeli",
  CanTeach = "Öğretebilir"
}

export interface KPI {
  label: string;
  value: string | number;
  trend: "up" | "down" | "neutral";
}

export interface ASA {
  label: string;
  weight: number;
  status: "strong" | "developing" | "neutral";
  kpi?: KPI[];
}

export interface Employee {
  id: string;
  name: string;
  role: Role;
  level: MasteryLevel;
  tenure: string;
  avatar?: string;
  asaMap: ASA[];
  skills: {
    topic: string;
    status: SkillStatus;
    date: string;
  }[];
  tendency: number[]; // 0-5 trend
  strongPoint: string;
  growthEdge: string;
}

export interface ShiftAssignment {
  employeeId: string;
  zone: string;
  time: string;
  justification: string;
}
