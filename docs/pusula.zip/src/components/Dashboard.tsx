import { motion } from "motion/react";
import { Employee } from "../types";

interface DashboardProps {
  employees: Employee[];
}

export default function Dashboard({ employees }: DashboardProps) {
  return (
    <div className="space-y-16">
      <div className="grid grid-cols-12 gap-8 items-end relative">
        <div className="col-span-8">
          <div className="label-caps italic opacity-50 mb-4 tracking-[0.5em]">Volume 01: L'Esprit</div>
          <h1 className="text-[120px] leading-[0.8] tracking-tighter mb-8 font-serif uppercase">
            YAŞAYAN<br/>
            <span className="pl-16 serif-italic opacity-80">UZMAN</span>
          </h1>
          <p className="max-w-md font-sans text-sm leading-relaxed opacity-80 border-l border-ink/20 pl-6">
            Gelişimin sürekliliği üzerine akademik bir vizyon. Verinin sezgiyle, planın icrayla buluştuğu nokta: <span className="font-bold">Herkes gelişir.</span>
          </p>
        </div>
        <div className="col-span-4 flex flex-col items-end">
          <div className="art-card aspect-square w-full max-w-[240px] flex flex-col justify-between">
            <div className="label-caps text-center opacity-60">Seviye Özeti</div>
            <div className="text-center font-serif text-4xl italic">{employees.length}</div>
            <div className="text-[10px] text-center opacity-40">Aktif Profil</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          { label: "Güçlü Yan", title: "Müşteri Servisi", desc: "Conversion Lift ortalaması geçen haftaya göre +12% arttı.", color: "bg-ink" },
          { label: "Tıkanıklık", title: "One Store", desc: "6 ekip üyesinde bu konu 'Geliştirilmeli' seviyesinde.", color: "bg-transparent border border-ink" },
          { label: "AI Vizyon", title: "Usta Aktarımı", desc: "Selin Yılmaz bu hafta yeni 'Öğretme Kartı' çıkarabilir.", color: "bg-[#E0DBCF]" },
        ].map((item, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="art-card flex flex-col justify-between aspect-[4/5]"
          >
            <div>
              <div className="label-caps mb-8 opacity-40">{item.label}</div>
              <h3 className="text-3xl font-serif mb-4 leading-tight">{item.title}</h3>
              <p className="text-sm opacity-60 leading-relaxed italic">{item.desc}</p>
            </div>
            <div className={`w-8 h-8 rounded-full ${item.color}`}></div>
          </motion.div>
        ))}
      </div>

      <div className="border-t border-ink pt-16">
        <h3 className="label-caps mb-12">Aktif Gelişim Arşivi</h3>
        <div className="grid grid-cols-1 gap-[1px] bg-border border border-border">
          {employees.map((emp) => (
            <div key={emp.id} className="flex items-center justify-between p-8 bg-canvas hover:bg-white transition-colors group">
              <div className="flex items-center gap-12">
                <div className="w-16 h-16 rounded-full border border-ink flex items-center justify-center font-serif italic text-xl group-hover:bg-ink group-hover:text-canvas transition-all">
                  0{emp.id}
                </div>
                <div>
                  <div className="label-caps text-xs mb-1">{emp.name}</div>
                  <div className="font-serif italic text-lg opacity-60">{emp.level}</div>
                </div>
              </div>
              <div className="hidden md:block">
                <div className="label-caps opacity-30 mb-1">Odak</div>
                <div className="text-sm font-bold tracking-tight">{emp.growthEdge}</div>
              </div>
              <div className="text-right">
                <div className="text-[32px] font-serif italic">{(emp.tendency[emp.tendency.length - 1] * 20)}%</div>
                <div className="label-caps opacity-40">Beceri Skoru</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
