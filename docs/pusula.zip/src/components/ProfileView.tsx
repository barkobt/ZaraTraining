import { motion } from "motion/react";
import { Target, BarChart3, GraduationCap } from "lucide-react";
import { Employee, SkillStatus } from "../types";

interface ProfileDetailProps {
  employee: Employee;
}

export default function ProfileDetail({ employee }: ProfileDetailProps) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 pb-20">
      {/* Sidebar Info */}
      <div className="lg:col-span-4 space-y-12">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="art-card text-center"
        >
          <div className="w-32 h-32 rounded-full border border-ink mx-auto flex items-center justify-center bg-transparent mb-8 overflow-hidden">
            <div className="font-serif text-5xl italic">{employee.name[0]}</div>
          </div>
          <h2 className="font-serif text-4xl font-bold mb-2 uppercase tracking-tight">{employee.name}</h2>
          <div className="label-caps opacity-40 mb-8">{employee.role}</div>
          
          <div className="grid grid-cols-1 gap-8 text-left pt-12 border-t border-border">
            <section>
              <div className="label-caps mb-2 opacity-50">Güçlü Odak</div>
              <div className="font-serif italic text-xl">{employee.strongPoint}</div>
            </section>
            <section>
              <div className="label-caps mb-2 opacity-50">Gelişim Kenarı</div>
              <div className="font-serif italic text-xl text-ink underline decoration-dotted underline-offset-4">{employee.growthEdge}</div>
            </section>
          </div>
        </motion.div>

        <div className="art-card">
          <h3 className="label-caps mb-8 flex items-center gap-4">
            <Target size={14} className="opacity-40" />
            ASA Dökümü
          </h3>
          <div className="space-y-8">
            {employee.asaMap.map((asa) => (
              <div key={asa.label} className="space-y-4">
                <div className="flex justify-between items-baseline">
                  <span className="text-xs font-bold uppercase tracking-widest">{asa.label}</span>
                  <span className="font-mono text-[10px] opacity-40">%{asa.weight}</span>
                </div>
                <div className="h-[1px] bg-border relative">
                  <div 
                    className="h-[3px] bg-ink absolute -top-[1px] transition-all duration-1000" 
                    style={{ width: `${asa.weight}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="lg:col-span-8 space-y-12">
        <div className="art-card">
          <h3 className="label-caps mb-12 flex items-center gap-4 border-b border-border pb-4">
            <GraduationCap size={14} className="opacity-40" />
            Konu Hakimiyet Matrisi
          </h3>
          <div className="grid grid-cols-1 gap-8">
            {employee.skills.map((skill) => (
              <div key={skill.topic} className="flex items-end justify-between group">
                <div>
                  <div className="label-caps text-[9px] opacity-40 mb-1">Dönem: {skill.date}</div>
                  <h4 className="font-serif text-2xl italic">{skill.topic}</h4>
                </div>
                <div className="flex flex-col items-end">
                  <div className="text-[10px] font-sans font-bold uppercase tracking-widest mb-2 italic">{skill.status}</div>
                  <div className="w-48 h-[1px] bg-border overflow-hidden">
                    <div 
                      className={`h-full transition-all duration-700 ${
                        skill.status === SkillStatus.CanTeach ? 'bg-ink' : 
                        skill.status === SkillStatus.CanDo ? 'bg-ink/60' :
                        'bg-ink/20'
                      }`} 
                      style={{ width: skill.status === SkillStatus.CanTeach ? '100%' : skill.status === SkillStatus.CanDo ? '60%' : '30%' }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="art-card !p-0 overflow-hidden flex flex-col md:flex-row">
          <div className="p-8 flex-1 border-r border-border">
            <h3 className="label-caps mb-12 flex items-center gap-4">
              <BarChart3 size={14} className="opacity-40" />
              Gelişim Eğrisi
            </h3>
            <div className="flex items-end gap-4 h-48 pt-4">
              {employee.tendency.map((score, i) => (
                <div key={i} className="flex-1 flex flex-col items-center gap-4">
                  <div className="w-full bg-border transition-all duration-700 relative group" style={{ height: `${(score/5)*100}%` }}>
                    <div className="absolute inset-0 bg-ink opacity-0 group-hover:opacity-10 transition-opacity" />
                  </div>
                  <span className="label-caps text-[8px] opacity-40">Q{i+1}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="p-8 bg-ink text-canvas w-full md:w-1/3 flex flex-col justify-between aspect-square md:aspect-auto">
            <div className="label-caps opacity-40">Yönetici Özeti</div>
            <p className="serif-italic text-lg leading-relaxed opacity-90 italic">
              "L'Esprit de {employee.name.split(' ')[0]}. Beceri matrisi tam yetkinlik sinyali veriyor. Gelişim kenarı artık sadece usta aktarımı üzerinde."
            </p>
            <div className="flex justify-center">
              <div className="w-16 h-[1px] bg-canvas/30 relative">
                <div className="absolute w-2 h-2 bg-canvas -top-[3.5px] left-1/2"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
