import { motion } from "motion/react";
import { Sparkles, BrainCircuit, Clock } from "lucide-react";
import { Employee } from "../types";

interface SolverProps {
  employees: Employee[];
}

export default function SolverView({ employees }: SolverProps) {
  const recommendations = [
    {
      seniorId: "1", // Selin
      juniorId: "2", // Mert
      zone: "Kabin 18:00 (Tepe Saat)",
      reason: "Conversion lift korunması için Selin tecrübesi; Mert'in gelişimine Selin katan (Usta Aktarımı) etkisi için.",
      impact: "High"
    },
    {
      seniorId: "3", // Baran
      juniorId: "new_1",
      zone: "Satış Alanı Z2",
      reason: "Baran'ın 'Koçluk Becerileri' gelişimi için yeni adayla birebir saha koçluğu.",
      impact: "Growth Focus"
    }
  ];

  return (
    <div className="space-y-12">
      <div className="flex items-end justify-between border-b border-ink pb-8">
        <div>
          <div className="label-caps opacity-40 mb-2 italic">Volume 01: L'Ordre</div>
          <h2 className="font-serif text-5xl font-bold tracking-tighter uppercase">GEREKÇELİ<br/>YERLEŞTİRME</h2>
        </div>
        <motion.button 
          whileTap={{ scale: 0.98 }}
          className="bg-ink text-canvas px-8 py-4 rounded-full label-caps flex items-center gap-3 hover:opacity-90 transition-all font-bold"
        >
          <Sparkles size={14} />
          Planı Uygula
        </motion.button>
      </div>

      <div className="grid grid-cols-1 gap-8">
        {recommendations.map((rec, i) => {
          const senior = employees.find(e => e.id === rec.seniorId);
          const junior = employees.find(e => e.id === rec.juniorId);

          return (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="art-card flex flex-col md:flex-row gap-12 items-center"
            >
              <div className="flex -space-x-8">
                <div className="w-24 h-24 rounded-full border-[6px] border-canvas bg-ink flex items-center justify-center text-canvas font-serif italic text-2xl shadow-xl">
                  {senior?.name[0]}
                </div>
                {junior ? (
                  <div className="w-24 h-24 rounded-full border-[6px] border-canvas bg-[#E0DBCF] flex items-center justify-center text-ink font-serif italic text-2xl shadow-xl">
                    {junior.name[0]}
                  </div>
                ) : (
                  <div className="w-24 h-24 rounded-full border-[6px] border-canvas bg-canvas flex items-center justify-center text-ink/20 font-serif italic text-2xl shadow-inner border-dashed">
                    ?
                  </div>
                )}
              </div>

              <div className="flex-1 space-y-2">
                <div className="label-caps opacity-40 flex items-center gap-2">
                  <Clock size={12} />
                  16:00 - 20:00 Vardiyası
                </div>
                <h3 className="font-serif text-4xl mb-1 tracking-tight">{rec.zone}</h3>
                <div className="label-caps px-0">
                  <span className="opacity-100">{senior?.name}</span>
                  {junior && <span className="opacity-40 italic mx-2">&</span>}
                  {junior && <span className="opacity-100">{junior.name}</span>}
                </div>
              </div>

              <div className="max-w-md bg-transparent p-6 border-l border-border italic text-sm leading-relaxed opacity-70">
                <div className="flex gap-4">
                  <BrainCircuit size={18} className="shrink-0 mt-1 opacity-40" />
                  <p>
                    <span className="font-bold label-caps block mb-2 not-italic underline decoration-ink/10">AI Tezi</span>
                    "{rec.reason}"
                  </p>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
