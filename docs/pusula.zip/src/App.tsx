/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Compass, 
  BarChart3, 
  Users, 
  Calendar, 
  Settings,
  Bell,
  Search
} from "lucide-react";
import { MOCK_EMPLOYEES } from "./mockData";
import Dashboard from "./components/Dashboard";
import ProfileDetail from "./components/ProfileView";
import SolverView from "./components/SolverView";

export default function App() {
  const [activeTab, setActiveTab] = useState("report");
  const [selectedUser, setSelectedUser] = useState(MOCK_EMPLOYEES[0]);

  return (
    <div className="min-h-screen bg-canvas flex flex-col font-sans">
      {/* Header */}
      <header className="h-24 bg-canvas border-b border-border px-12 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-16">
          <div className="flex flex-col">
            <div className="label-caps italic opacity-60 mb-1 leading-none">Studio Pusula</div>
            <h1 className="font-serif text-2xl font-bold tracking-tight">VİZYONNER</h1>
          </div>
          
          <nav className="hidden md:flex gap-8">
            {[
              { id: "report", label: "Dashboard" },
              { id: "competency", label: "Profil" },
              { id: "generate", label: "Yerleştir" },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`label-caps pb-1 transition-all relative ${
                  activeTab === tab.id ? 'text-ink' : 'opacity-40 hover:opacity-100'
                }`}
              >
                {tab.label}
                {activeTab === tab.id && (
                  <motion.div 
                    layoutId="activeTab"
                    className="absolute -bottom-1 left-0 w-full h-[1px] bg-ink" 
                  />
                )}
              </button>
            ))}
          </nav>
        </div>

        <div className="flex items-center gap-6">
          <div className="text-right hidden lg:block">
            <div className="label-caps opacity-40 mb-1 uppercase">Konum</div>
            <div className="text-[11px] font-bold">Bornova / ZARA</div>
          </div>
          <div className="w-10 h-10 rounded-full border border-ink flex items-center justify-center italic text-sm">
            BB
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl mx-auto w-full p-12">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
          >
            {activeTab === "report" && <Dashboard employees={MOCK_EMPLOYEES} />}
            
            {activeTab === "competency" && (
              <div className="space-y-12">
                <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-none border-b border-border">
                  {MOCK_EMPLOYEES.map(emp => (
                    <button
                      key={emp.id}
                      onClick={() => setSelectedUser(emp)}
                      className={`label-caps px-4 py-2 transition-all ${
                        selectedUser.id === emp.id 
                          ? 'text-ink italic' 
                          : 'opacity-30 hover:opacity-100'
                      }`}
                    >
                      {emp.name}
                    </button>
                  ))}
                </div>
                <ProfileDetail employee={selectedUser} />
              </div>
            )}

            {activeTab === "generate" && <SolverView employees={MOCK_EMPLOYEES} />}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}
